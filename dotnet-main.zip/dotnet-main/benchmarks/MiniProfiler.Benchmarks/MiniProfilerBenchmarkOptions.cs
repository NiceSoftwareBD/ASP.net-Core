﻿using StackExchange.Profiling.Internal;

namespace Benchmarks
{
    public class MiniProfilerBenchmarkOptions : MiniProfilerBaseOptions
    {
    }
}
