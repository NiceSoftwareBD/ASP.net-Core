﻿# ASP.NET Core 2.2
--------
This is a sample project demonstrating how MiniProfiler can be used in ASP.NET Core 2.2.