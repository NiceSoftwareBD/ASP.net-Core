﻿# ASP.NET Core 3.0 (preview) Sample
--------
This is a sample project demonstrating how MiniProfiler can be used in ASP.NET Core 3.0.