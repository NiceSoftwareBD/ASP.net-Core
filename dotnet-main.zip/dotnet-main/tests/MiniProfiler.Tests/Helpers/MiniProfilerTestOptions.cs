﻿using StackExchange.Profiling.Internal;

namespace StackExchange.Profiling.Tests.Helpers
{
    public class MiniProfilerTestOptions : MiniProfilerBaseOptions
    {
    }
}
